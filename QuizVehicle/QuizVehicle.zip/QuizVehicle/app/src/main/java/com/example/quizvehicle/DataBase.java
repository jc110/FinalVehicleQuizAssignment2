package com.example.quizvehicle;

public class DataBase {
    Integer[] vehicle = {
            R.drawable.car_image_1,
            R.drawable.carimage2,
            R.drawable.image3,
            R.drawable.image4,
            R.drawable.image5,
            R.drawable.image6,
            R.drawable.image7,
            R.drawable.image8,
            R.drawable.image9,
            R.drawable.image10,
            R.drawable.image10,
            R.drawable.image11,
            R.drawable.image12,
            R.drawable.image13,
            R.drawable.image14,
            R.drawable.image15,
            R.drawable.image16,
            R.drawable.image17,
            R.drawable.image18,
            R.drawable.image19,
            R.drawable.image20,
            R.drawable.image21

    };
    String[] answer={
           "Car",
           "SportCar",
            "Yellow Car",
            "SUV",
            "Truck",
            "Freight Truck",
            "White Truck ",
            "Dump Truck",
            "White Bus",
            "Front Loader",
            "Toy Car",
            "Ice Cub Car",
            "Cartoon Truck",
            "Christmas car",
            "Ford Truck",
            "Kid Truck",
            "Kid Red Truck",
            "Cartoon Car",
            "Orange Truck",
            "Yellow wool car",
            "Snow Car"
    };
}
