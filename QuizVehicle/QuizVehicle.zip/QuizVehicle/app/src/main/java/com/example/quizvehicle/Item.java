package com.example.quizvehicle;

public class Item {
 String name;
 int image;

        public Item(String name, int image)
 {
     this.name=name;
     this.image=image;

 }

    public String getName() {
        return name;
    }

    public int getImage() {
        return image;
    }

}
